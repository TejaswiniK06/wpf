﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CarInfoBLL;
using CarInfoEntities;
using CarInfoException;
using System.Data;
using System.Data.SqlClient;

namespace CarInfoPLWPF
{
    /// <summary>
    /// Interaction logic for ListOfByType.xaml
    /// </summary>
    public partial class ListOfByType : Window
    {
        public ListOfByType()
        {
            InitializeComponent();
        }

        private void Btnlistby_Click(object sender, RoutedEventArgs e)
        {
            list();
        
            }
        private void list()
        {
            try
            {
                string cartype = txtcartype.Text;
                    string manufname = txtmanuf.Text;

                CarBLL bLL = new CarBLL();
                DataTable dt = bLL.SearchByAdminBLL(manufname,cartype);
                dg.DataContext = dt;



            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
