﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CarInfoBLL;
using CarInfoEntities;
using CarInfoException;
using System.Data;
using System.Data.SqlClient;

namespace CarInfoPLWPF
{
    /// <summary>
    /// Interaction logic for SearchByModel.xaml
    /// </summary>
    public partial class SearchByModel : Window
    {
        public SearchByModel()
        {
            InitializeComponent();
        }

        private void BtnSearchModel_Click(object sender, RoutedEventArgs e)
        {
            Searchmodel();
        }
        private void Searchmodel()
        {
            try
            {
               // MainCar car = new MainCar();
                CarBLL bLL = new CarBLL();
                string model = (txtModel.Text);
               
                    DataTable dt = bLL.SearchByModelBLL( model);
                dg.DataContext = dt;



            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btnback_Click(object sender, RoutedEventArgs e)
        {
            MainPage mainPage = new MainPage();
            mainPage.Show();
            this.Hide();


        }
    }
}
