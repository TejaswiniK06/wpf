﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CarInfoBLL;
using CarInfoEntities;
using CarInfoException;
using System.Data;
using System.Data.SqlClient;

namespace CarInfoPLWPF
{
    /// <summary>
    /// Interaction logic for Update.xaml
    /// </summary>
    public partial class Update : Window
    {
        public Update()
        {
            InitializeComponent();
            txtEng.Visibility = Visibility.Hidden;
            txtBHP.Visibility = Visibility.Hidden;
            txtMileage.Visibility = Visibility.Hidden;
            txtSeat.Visibility = Visibility.Hidden;
            txtAirBag.Visibility = Visibility.Hidden;
            txtBootSpace.Visibility = Visibility.Hidden;
            txtPrice.Visibility = Visibility.Hidden;
            txtManfName.Visibility = Visibility.Hidden;
            txtConPerson.Visibility = Visibility.Hidden;
            txtRegOff.Visibility = Visibility.Hidden;
            cmbTypeId.Visibility = Visibility.Hidden;
            cmbTransId.Visibility = Visibility.Hidden;
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            updatecar();
        }
        private void updatecar()
        {
            try
            {
                MainCar mainCar = new MainCar();

                Manufacturer manuf = new Manufacturer();
                mainCar.Model = txtModel.Text;
                mainCar.Engine = txtEng.Text;
                mainCar.BHP = int.Parse(txtBHP.Text);
                mainCar.Mileage = int.Parse(txtMileage.Text);
                mainCar.Seat = int.Parse(txtSeat.Text);
                mainCar.AirBagDetails = txtAirBag.Text;
                mainCar.BootSpace = txtBootSpace.Text;
                mainCar.Price = txtPrice.Text;
                manuf.ManufacturerName = txtManfName.Text;
                manuf.ContactPerson = txtConPerson.Text;
                manuf.RegisteredOffice = txtRegOff.Text;
                mainCar.TypeId = Convert.ToInt32(cmbTypeId.SelectedValue);
                mainCar.TransmissionId = Convert.ToInt32(cmbTransId.SelectedValue);

                CarBLL bLL = new CarBLL();

                if (bLL.UpdateByAdminBLL(mainCar, manuf))
                {
                    MessageBox.Show("Car details Updated Successfully");
                }
                else
                {
                    MessageBox.Show("Failed to update car details");
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetTrans();
            GetTypeId();
            
           


        }
        private void GetTrans()
        {
            CarBLL bLL = new CarBLL();
            try
            {
                DataTable translist = bLL.GetCarTransmissionTableBLL();
                cmbTransId.ItemsSource = translist.DefaultView;
                cmbTransId.DisplayMemberPath = translist.Columns[1].ColumnName;
                cmbTransId.SelectedValuePath = translist.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetTypeId()
        {
            CarBLL bLL = new CarBLL();
            try
            {
                DataTable translist = bLL.GetCarTypeTableBLL();
                cmbTypeId.ItemsSource = translist.DefaultView;
                cmbTypeId.DisplayMemberPath = translist.Columns[1].ColumnName;
                cmbTypeId.SelectedValuePath = translist.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void getmodel()
        {
            try
            {
                // MainCar mainCar = null;
                string model = txtModel.Text;
                CarBLL bLL = new CarBLL();
                DataTable dt = bLL.SearchByModelBLL(model);
                if (dt.Rows.Count > 0)
                {

                    while (dt.Rows.Count > 0)

                    {
                        txtEng.Visibility = Visibility.Visible;
                        txtBHP.Visibility = Visibility.Visible;
                        txtMileage.Visibility = Visibility.Visible;
                        txtSeat.Visibility = Visibility.Visible;
                        txtAirBag.Visibility = Visibility.Visible;
                        txtBootSpace.Visibility = Visibility.Visible;
                        txtPrice.Visibility = Visibility.Visible;
                        txtManfName.Visibility = Visibility.Visible;
                        txtConPerson.Visibility = Visibility.Visible;
                        txtRegOff.Visibility = Visibility.Visible;
                        cmbTypeId.Visibility = Visibility.Visible;
                        cmbTransId.Visibility = Visibility.Visible;
                        txtModel.Text = dt.Rows[0]["Model"].ToString();


                        txtEng.Text = dt.Rows[0]["Engine"].ToString();
                        txtPrice.Text = dt.Rows[0]["Price"].ToString();
                        txtAirBag.Text = dt.Rows[0]["AirBagDetails"].ToString();
                        txtBootSpace.Text = dt.Rows[0]["BootSpace"].ToString();
                        txtBHP.Text = dt.Rows[0]["BHP"].ToString();
                        txtMileage.Text = dt.Rows[0]["Mileage"].ToString();
                        txtManfName.Text = dt.Rows[0]["ManufacturerName"].ToString();
                        txtConPerson.Text = dt.Rows[0]["ContactPerson"].ToString();
                        txtSeat.Text = dt.Rows[0]["Seat"].ToString();
                        txtRegOff.Text = dt.Rows[0]["RegisteredOffice"].ToString();
                        cmbTypeId.SelectedValue = dt.Rows[0]["TypeId"].ToString();
                        cmbTransId.SelectedValue = dt.Rows[0]["TypeId"].ToString();



                        break;
                    }
                }

                else
                {
                    MessageBox.Show(" Car details with given Model is not found");
                }

            }
            
           catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btnsearchtoupdate_Click(object sender, RoutedEventArgs e)
        {
            getmodel();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            delete();
        }
        private void delete()
        {
            try
            {
               
                bool isCarDeleted;
                string model = txtModel.Text;
                
                CarBLL bLL = new CarBLL();
                isCarDeleted = bLL.DeleteBLL(model);
                if (isCarDeleted == true)
                {
                    MessageBox.Show("CarModel " +model +" deleted successfully");
                }
                else
                {
                    MessageBox.Show("Car "+model +" not found");
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
